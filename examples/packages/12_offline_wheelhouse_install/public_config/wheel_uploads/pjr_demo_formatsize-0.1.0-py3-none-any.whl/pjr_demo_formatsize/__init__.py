"""Offline vendored requirements demo package."""

__version__ = "0.1.0"

def naturalsize(value: int) -> str:
    """Return a simple decimal human-readable size string."""
    if value < 1000:
        return f"{value} Bytes"
    if value < 1000 ** 2:
        return f"{value / 1000:.1f} kB"
    return f"{value / 1000 ** 2:.1f} MB"
